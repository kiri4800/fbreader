package com.example.fbreader.Bookfileadapter;

import androidx.annotation.Nullable;

import org.fbreader.book.Book;

public class BookFile {
    private String name;
    private String path;
    public BookFile(String name,String path){
        this.name = name;
        this.path = path;
    }
    public String getName(){
        return name;
    }
    public String getPath(){
        return path;
    }
    public void setName(String name){
        this.name = name;
    }
    public void setPath(String path){
        this.path = path;
    }

//    @Override
//    public boolean equals(@Nullable Object obj) {
//        if(obj instanceof BookFile){
//            BookFile f =
//        }
//        return false;
//    }
}
